#!/bin/sh
if [ $# != 1 ]
then
	exit 1
fi

if [ "$1" = "-c" ]
then
	date=\"`date`\"
	version=0.1.1
	cat > src/config.h << EOF
DATE=$date
VERSION=$version
EOF
	exit 0
else 
	. ./src/config.h || exit 1
	. ./makefile.in  || exit 1
fi

PREFIX=$1

mkdir -p $PREFIX
mkdir -p $PREFIX/bin
mkdir -p $PREFIX/include
mkdir -p $PREFIX/lib
mkdir -p $PREFIX/man/man7
[ -n "$MAKEDOC" ] && mkdir -p $PREFIX/share/doc

mkdir -p tmp
mkdir -p tmp/bin
mkdir -p tmp/include
mkdir -p tmp/lib
mkdir -p tmp/man/man7
mkdir -p tmp/man/man5
[ -n "$MAKEDOC" ] && mkdir -p tmp/share/doc

cp src/liblongvol.so src/liblongvol.a tmp/lib
cp src/longvol.h tmp/include
cp -f src/man7/* tmp/man/man7
cp -f src/man5/* tmp/man/man5
[ -n "$MAKEDOC" ] && cp -r src/doc tmp/share/doc/liblongvol


find tmp -name "*.html" -o -name "*.5" -o -name "*.7" -o -name Doxyfile | \
while read m ; \
do \
	echo updating $m ; \
	sed "s/__DATE__/$DATE/g;s/__VERSION__/$VERSION/g;s!__PREFIX__!$PREFIX!g" "$m" > /tmp/m.$$ && mv /tmp/m.$$ $m ; \
done   

cp tmp/lib/liblongvol.so tmp/lib/liblongvol.a $PREFIX/lib
cp tmp/include/longvol.h $PREFIX/include
cp tmp/man/man7/* $PREFIX/man/man7
cp tmp/man/man5/* $PREFIX/man/man5
[ -n "$MAKEDOC" ] && rm -rf $PREFIX/share/doc/liblongvol
[ -n "$MAKEDOC" ] && cp -r tmp/share/doc/liblongvol $PREFIX/share/doc/liblongvol

cat > uninstall.sh << EOF
#!/bin/sh
# This is a generated unistall script 
rm -f $PREFIX/lib/liblongvol.*
rm -f $PREFIX/include/longvol.h
rm -f $PREFIX/man/man5/longvolformat.5
rm -f $PREFIX/man/man7/longvol.7
rm -rf $PREFIX/share/doc/liblongvol
EOF
chmod +x uninstall.sh

rm -rf tmp
