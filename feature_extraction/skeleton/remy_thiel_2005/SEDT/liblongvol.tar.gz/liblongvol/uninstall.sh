#!/bin/sh
# This is a generated unistall script 
rm -f /home/dcoeurjo/local/lib/liblongvol.*
rm -f /home/dcoeurjo/local/include/longvol.h
rm -f /home/dcoeurjo/local/man/man5/longvolformat.5
rm -f /home/dcoeurjo/local/man/man7/longvol.7
rm -rf /home/dcoeurjo/local/share/doc/liblongvol
