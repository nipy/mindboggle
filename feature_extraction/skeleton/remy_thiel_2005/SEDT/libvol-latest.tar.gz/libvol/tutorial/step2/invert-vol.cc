#include <vol.h>
#include <stdio.h>

int main( int argc, char **argv ) {

	char *source_file = "";
	char *dest_file = "";

	if (argc > 1) { 
		source_file = argv[1];
		if (argc > 2)
			dest_file = argv[2];
	}

	Vol v( source_file );

	if (!v.isOK()) {
		fprintf( stderr, "Couldn't load \"%s\" file !\n", source_file );
		return 1;
	}
	
	voxel alpha_color = v.alpha();

	for (int i = v.minX(); i < v.maxX(); ++i) {                               
		for (int j = v.minY(); j < v.maxY(); ++j) {
			for (int k = v.minZ(); k < v.maxZ(); ++k) {
				
				if (v(i, j, k) == alpha_color)
					v(i, j, k) = 50;
				else
					v(i, j, k) = alpha_color;
			
			}
		}
	}

	v.dumpVol( dest_file );

	return 0;
				
}
