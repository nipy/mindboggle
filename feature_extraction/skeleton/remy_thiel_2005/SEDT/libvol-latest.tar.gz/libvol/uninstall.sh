#!/bin/sh
# This is a generated unistall script 
rm -f /home/alexis/local/lib/libvol.*
rm -f /home/alexis/local/include/vol.h
rm -f /home/alexis/local/man/man5/volformat.5
rm -f /home/alexis/local/man/man7/vol.7
rm -rf /home/alexis/local/share/doc/libvol
